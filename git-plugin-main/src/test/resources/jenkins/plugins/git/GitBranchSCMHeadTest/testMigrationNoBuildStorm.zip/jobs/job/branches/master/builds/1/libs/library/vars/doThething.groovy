
def call() {
    def txt = libraryResource('thething.txt')
    echo txt
}
