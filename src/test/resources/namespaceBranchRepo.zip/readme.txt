This is a test repository containing namespace branches used to test the git client plugin.\n
Execute create.sh in an empty folder to recreate this repository.\n\n
Copy the namespaceBranchRepo.zip and namespaceBranchRepo.ls-remote to src/test/resources/.\n\n
