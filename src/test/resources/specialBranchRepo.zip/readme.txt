This is a test repository containing all kinds of (weird) branches, tags, etc. used to test the git client plugin.\n
Execute create.sh in an empty folder to recreate this repository.\n\n
Copy the specialBranchRepo.zip and specialBranchRepo.ls-remote to src/test/resources/.\n\n
